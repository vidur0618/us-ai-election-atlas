AI, DATA CENTERS AND THE 2026 US MIDTERMS
DASHBOARD IMPORT BUNDLE
Research cutoff: 2026-11-13
Dataset version: 2026-11-13-v1
Canonical SHA-256: 31fa31c14f26ec3d9404c0c549d088dacfd4f8dcf70f8e8f7102dab77607114a

1. WHAT THIS BUNDLE IS

This is the dashboard-ready companion to the research dossier. It preserves the
identified public ballot questions, selected candidate contests and recalls,
state-control snapshots, selected state policies, survey observations, sources,
and an explicitly separate external candidate tracker. It is an audited research
inventory, NOT a certified exhaustive national registry of every local election,
every AI-adjacent question, or every state bill. The 50 states and DC are indexed;
absence of an identified record is a coverage finding, not a certified zero.

ai_midterms_2026_data.json is the authoritative lossless file. It is a byte-for-byte
copy of the final canonical JSON, including all nested values, sources, notes,
historical versions, raw counts, missing fields, and explicit nulls. Each top-level
array also has a CSV. The three object components have separate JSON files.
No raw downloaded webpages, copyrighted article archives, build scripts, or QA
previews are included.

2. FILES AND ROW COUNTS

  states: 51 rows -> tables/states.csv
  ballots: 67 rows -> tables/ballots.csv
  control_changes: 15 rows -> tables/control_changes.csv
  chamber_snapshots: 13 rows -> tables/chamber_snapshots.csv
  elections: 21 rows -> tables/elections.csv
  election_choices: 90 rows -> tables/election_choices.csv
  recalls: 10 rows -> tables/recalls.csv
  policies: 138 rows -> tables/policies.csv
  polls: 89 rows -> tables/polls.csv
  exclusions: 14 rows -> tables/exclusions.csv
  gaps: 10 rows -> tables/gaps.csv
  data_dictionary: 15 rows -> tables/data_dictionary.csv
  sources: 316 rows -> tables/sources.csv
  tracker_results: 1,064 rows -> tracker/results.csv
  tracker_candidates_on_record: 892 rows -> tracker/positions.csv
  tracker_winner_index: 370 rows -> tracker/winner_index.csv
  tracker_state_counts: 49 rows -> tracker/state_counts.csv
  tracker_people_index: 349 rows -> tracker/people_index.csv
  source_conflicts: 9 rows -> tables/source_conflicts.csv

metadata.json: overall coverage, counts, and counting rules.
dashboard_spec.json: recommended filters, displays, aggregation rules, refresh order.
tracker/metadata.json: original tracker snapshot context and normalized counts.
export_schema.csv and export_schema.json: observed field types, null/missing counts,
  exact file mapping, and CSV conventions for every canonical list table.
MANIFEST.json: file sizes, SHA-256 hashes, CSV row counts, and descriptions.
validation.json: checks performed on this exact export and its foreign keys.

derived/ contains convenient child tables for recall options, legislative votes,
ballot county/precinct/mode components and historical snapshots, nested election
write-ins, an explicit ballot cohort crosswalk, and scalar source-URL locations.
These are alternate views of data already present in parent tables. Do not append
them to parent totals or count the same observation twice.

3. IMPORT TYPES, DATES, AND MISSING VALUES

CSV is UTF-8 without a BOM, comma-delimited, with a header, double-quoted cells as
needed, and LF newlines. Arrays and objects remain compact JSON strings inside
cells; parse them as JSON when using a relational/visual tool. All observed keys
are exported, even if a field appears in only one source record.

__row_index is the 1-based row position within that CSV. It is an export locator,
not an election ID, unique-person count, or stable cross-version identifier.
Child parent_row_index refers to the parent table's __row_index in this package.

Boolean values are true or false. A blank CSV cell means unknown, not reported,
inapplicable, absent, or an existing empty string; it does NOT mean zero. The exact
null-versus-missing-versus-empty-string distinction remains in the canonical JSON.
Literal numeric 0 is retained when supplied. Never fill unknown votes, percentages,
counts, or status fields with zero merely to make a visualization render.

Import state codes, record IDs, candidate IDs, race hashes, and FIPS values as
TEXT, preserving leading zeros. Exact dates generally use ISO YYYY-MM-DD. Mixed
source snapshots can contain time zones, prose, or date ranges and are preserved
as supplied. Do not assume UTC when a source omits its time zone. Election date,
source-update date, retrieval date, certification date, and legal effective date
are distinct fields; none may silently substitute for another.

All percentage fields in this ZIP use numeric percentage points from 0 to 100:
23 means 23%, not 0.23%. The separate XLSX uses Excel fractions internally; this
bundle does not. Raw votes and seats are counts. Margins of error in *_pp fields
are percentage points. Fields ending *_usd are US-dollar amounts, not vote counts.

4. THE 47-QUESTION / 48-QUESTION COHORT CROSSWALK

Use derived/ballot_cohort_crosswalk.csv to select a cohort explicitly.

  41 core_nov3 questions from the Ballotpedia component
 + 6 additional_nov3 questions (Americus, Brownfield, Eliot, Freedom, Sabattus,
     Belvidere)
 = 47 questions in the November 3 targeted tracker component.

 + 1 additional_land_use question (White Cloud Township general zoning)
 = 48 questions in the expanded November 3 data-center/development cohort.

Both cohorts contain 46 outcomes coded more_restrictive. Harwood is the sole
less-restrictive outcome in the 47-question component. White Cloud is the second
less-restrictive outcome in the expanded 48-question cohort. White Cloud is a
general-zoning question relevant to data-center development, not a text-specific
AI regulation. These are counts of questions, not numbers or percentages of voters.

The expanded 48 contains 38 binding and 10 advisory questions across 45
jurisdictions in 11 states. Advisory outcomes express voter preference and do
not automatically enact a ban or repeal. A successful anti-development advisory
choice must not be displayed as an enacted legal restriction.

There are 8 other November 3 technology/finance questions:
  ai_governance (2), ai_surveillance (2), ai_adjacent (2), broader_tax (1),
  broader_school_finance (1).
Thus the full November 3 question inventory has 56 records, while the complete
ballot table has 67 records: those 56, seven earlier-2026 records, and four future
scheduled records. Scheduled questions had not occurred by the November 13 cutoff.

Solano County's broader tax question and Mason County's broader school-finance
question are separately tagged finance context; neither is the 48th development
question. General AI governance, surveillance, and adjacent technology questions
must remain visibly distinguishable from land-use and data-center siting votes.

scope_group retains the detailed source classification:
  core_nov3, additional_nov3, additional_land_use: expanded development cohort
  ai_governance, ai_surveillance, ai_adjacent: other technology scopes
  broader_tax, broader_school_finance: broader finance context
  core_earlier, additional_earlier_townmeeting: earlier-2026 context
  scheduled: future event after the research cutoff

metadata.base_census is the retained component census, not the full final inventory.
For the full package use the top-level counts and the row-level crosswalk. The
more precise label nov3_development_cohort_questions should be preferred over the
legacy metadata alias nov3_targeted_dc_questions when labeling the 48-question view.

5. BALLOT POLARITY, DENOMINATORS, AND LEGAL EFFECT

Yes is not universally anti-data-center. yes_effect records restrict, permit, or
other. yes_pct_valid is 100 * yes_votes / (yes_votes + no_votes); no_pct_valid uses
the same denominator. restriction_vote_pct uses Yes share if Yes restricts, No
share if Yes permits, and is null for non-comparable questions. Preserve the
measure's own outcome and policy_summary alongside any harmonized direction.

reported_yes_pct retains the publisher's percentage. It may differ from a
calculated valid-Yes/No share because the publisher used blanks, other ballot
categories, a different snapshot, or a statutory threshold denominator. Read
reported_pct_denominator and notes. Do not overwrite reported values or infer a
legal pass/fail result from a simple majority when the measure uses another rule.
Conneaut and Honolulu are explicit examples requiring denominator attention.

valid_yes_no_votes is not turnout, registered voters, or all ballots cast. Blanks,
overvotes, undervotes, other ballots, county components, and voting-mode returns
are retained where supplied. Do not invent absent categories. Do not sum different
questions or overlapping jurisdictions into unique voters. Do not average local
question percentages into a representative national opinion estimate.

historical_versions are older snapshots, never additional votes. County, precinct,
and mode returns are components, not votes to add again to a parent's total.
primary_counts_verified means primary counts were read; it does not certify the
election, guarantee a complete count, or guarantee freshness. Most recent returns
remain provisional at this cutoff; preserve result_status and update dates.

6. CANDIDATE CONTESTS, RECALLS, CONTROL, AND POLICIES

The 21 selected elections and their 90 listed choices are not the same coverage
unit as the external tracker. election_choices is a normalized view of the
choices in elections; do not concatenate the two as independent observations.
share_of_listed_votes is calculated from options in one selected source snapshot.
reported_percent is kept separately. Read denominator_note before comparing them.
For vote-for-two offices, candidate totals count selections, not individual voters.
Nevada's None of These Candidates remains in the relevant listed denominator.

The Arizona governor nested write-in breakdown is preserved as subcomponents of
Adjudicated Write-Ins. The interpretation is documented in source notes. Never add
the subcomponents again when totaling listed choices. Do not mix a candidate from
one snapshot with opponents from another.

The recall table counts ten officials, not ten interchangeable policy questions or
unique voter groups. Recall Yes/No votes and replacement-candidate elections use
different denominators. derived/recall_choices.csv distinguishes choices from
replacement through parent_field. Petition campaigns, resignations, failed ballot
access, and later scheduled recall elections are not completed recall votes.

Control records distinguish chamber control, governor offices, holds, and context.
The 12 chambers entering Democratic control comprise 11 Republican-majority
chambers plus the previously tied Minnesota House. Virginia's governor flip is
2025 context, explicitly dated, rather than a November 2026 flip. Chamber snapshots
retain uncalled seats and source dates; incoming officials differ from current
officeholders. A candidate victory does not isolate voters' reason for voting or
prove support for a particular AI/data-center policy.

The 138 policy records are a selected policy register, not 138 enacted laws or an
exhaustive bill census. Some rows group companion bills or packages. Filed,
committee passage, chamber passage, enactment, effective date, executive action,
failed proposal, and campaign pledge are distinct statuses. Post-election proposals
are not retroactively enacted. Legislative votes are legislators' roll calls,
never public election returns. Unstructured roll-call statements remain text.

7. SURVEY OBSERVATIONS

The 89 poll rows are observations/crosstabs, not 89 independent polls or counted
ballots. percent is a reported weighted estimate, with publisher rounding. Preserve
question, response, subgroup, population, field dates, and conditions. Overall
sample size/design effect/margin of error are not necessarily question- or subgroup-
specific bases. Question sample and margin fields remain null when not available.
Do not sum subgroups into unique respondents or compare unlike questions as a trend.

8. EXTERNAL TRACKER: SEPARATE DISCOVERY LAYER

Source: https://ballot.dcmap.us/
Source snapshot: 2026-11-06. Retrieved: 2026-11-13.
All tracker-coded stances and results are explicitly NOT independently verified
or certified by this dossier. Candidate-source, result-source, and stance-source
URLs may differ. Tracker stance labels are source coding, not a conclusion inferred
from a candidate's party or electoral success.

The 1,064 result rows contain 1,005 source person IDs and 472 syntactic race hashes.
The hashes reflect source jurisdiction/office/district/date labels; aliases can
split one real contest into several hashes. They are not 472 verified unique races.
Result statuses: 416 won, 438 lost, 83 leading, 105 trailing, 7 too_close, 15 runoff.
All supplied result rows in this snapshot have election_date 2026-11-03. The
metadata's generic warning about checking dates should still be followed on refresh.

642 result rows contain a reported vote share; 422 do not. NO raw vote counts were
supplied in these 1,064 rows. Every missing raw count remains null; never derive a
vote count from a share without a supported denominator.

The positions file has 892 rows, including unclear or split codes and unresolved
results. It is not simply a subset of results.csv: 817 record IDs match result
rows and 75 additional position rows have no result status. Use an outer join or
retain the tables separately to avoid dropping those 75 records.

The source winner index has 370 rows: 314 won and 56 leading. It has 21 extra alias
rows for repeated people. The deduplicated people index has 349 people: 297 won and
52 leading. A source winner-index flag must not be interpreted as a certified win.
Raw winner-index stance rows are 174 against, 177 conditional, 19 for; unique-person
stance counts are 157 against, 173 conditional, 19 for. These are source-coded
categories, not an independent estimate of a national electoral mandate.

The source headline '442 results' is retained as source metadata. It is not safely
reconciled to physical contests and must not be subtracted from 370 to infer a
number of uncalled races. tracker/state_counts.csv contains 49 state records drawn
from tracker results/index coverage; it is not the complete 51-jurisdiction state
inventory. Its winning_* columns count raw winner-index rows, including leading
candidates and aliases; they must not be labeled confirmed seats won.

9. KEYS AND PROVENANCE

Use these joins:
  states.ballot_record_ids -> ballots.record_id
  states.policy_record_ids -> policies.record_id
  election_choices.election_id -> elections.record_id
  source_ids / source_id -> sources.source_id
  source_conflicts.tracker_record_id -> tracker_results.record_id
  tracker people/winner-index candidate_id -> tracker result/position candidate_id
    (one person can have several aliased result rows)

Tracker positions/results record_id is suitable for matching within this snapshot,
subject to the 75 position-only records. Do not use candidate names alone as keys.
State codes are geography joins, not proof of complete jurisdictional coverage.

The sources registry primarily documents reviewed core records. Tracker rows retain
additional public links that have not all been independently reviewed. All source
URLs remain in canonical/CSV cells. derived/source_links.csv indexes scalar URLs
with JSON pointers; URLs embedded inside notes remain in those original notes.
Internal source_refs/reference_ids are retrieval handles, not public URLs. Use
the public URL and the source snapshot for reproducible provenance.

source_conflicts contains nine differing selected/tracker share snapshots. These
are review flags, not adjudicated errors. Check candidate identity, contest,
snapshot timing, and denominator before preferring or combining observations.

10. FIRST DASHBOARD AND REFRESH

Start with the expanded 48-question cohort, showing an explicit 47-question tracker
crosswalk. Keep visible toggles for advisory votes, broader land use, AI governance,
surveillance, finance context, earlier elections, future schedules, and external
tracker data. Use raw Yes/No counts with polarity and denominators, state-level
question counts, dated chamber snapshots, and an actual-status policy matrix.
Show source date, status/certification, legal effect, and source URL in tooltips.

Refresh official canvasses first, then unresolved control races, unreadable county
returns, bill histories/2027 refilings, and court or implementation changes. Retain
old snapshots as history; do not silently replace a denominator or blend versions.
The canonical JSON, file hashes, source dates, and unresolved gaps should accompany
any published dashboard derived from this package.
